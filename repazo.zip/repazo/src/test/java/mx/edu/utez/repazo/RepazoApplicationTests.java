package mx.edu.utez.repazo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepazoApplicationTests {

	@Test
	void contextLoads() {
	}

}
