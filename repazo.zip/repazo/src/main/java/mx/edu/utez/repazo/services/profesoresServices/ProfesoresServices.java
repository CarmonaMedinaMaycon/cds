package mx.edu.utez.repazo.services.profesoresServices;

import mx.edu.utez.repazo.models.profesores.Profesores;
import mx.edu.utez.repazo.models.profesores.ProfesoresRepository;
import mx.edu.utez.repazo.utils.CustomResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ProfesoresServices {
@Autowired
    ProfesoresRepository repository;

@org.springframework.transaction.annotation.Transactional(readOnly = true)
    public CustomResponse<Profesores> getOne(Long id){
    return new CustomResponse<>(
            this.repository.findById(id).get(),
            false,
            200,
            "ok infiel"
    );
}

@org.springframework.transaction.annotation.Transactional(readOnly = true)
    public CustomResponse<List<Profesores>> getAll(){
    return new CustomResponse<>(
            this.repository.findAll(),
            false,
            200,
            "ok infiel"
    );
}

@org.springframework.transaction.annotation.Transactional
    public CustomResponse<Profesores> insert(Profesores profesores){
    return new CustomResponse<>(
            this.repository.saveAndFlush(profesores),
            false,
            200,
            "ok infiel"
    );
}

@org.springframework.transaction.annotation.Transactional(readOnly = true)
    public CustomResponse<Profesores> update(Profesores profesores){
    return new CustomResponse<>(
            this.repository.saveAndFlush(profesores),
            false,
            200,
            "ok infiel"
    );
}


}
