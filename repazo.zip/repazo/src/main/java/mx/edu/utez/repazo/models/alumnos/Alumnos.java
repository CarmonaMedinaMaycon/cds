package mx.edu.utez.repazo.models.alumnos;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "alumnos")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Alumnos {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

@Column
    String nombre;
@Column(nullable = false,length = 250)
    String apellidos;
@Column(nullable = false)
    int edad;



}
