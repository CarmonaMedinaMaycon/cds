package mx.edu.utez.repazo.controllers.profesoresController.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.repazo.models.profesores.Profesores;

import javax.persistence.Column;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter

public class ProfesorDTO {
    Long id;
    String nombre;
    String apellido;
    int edad;


    public Profesores getProfesor(){
        return new Profesores(
                getId(),
                getNombre(),
                getApellido(),
                getEdad()
        );
    }

}
