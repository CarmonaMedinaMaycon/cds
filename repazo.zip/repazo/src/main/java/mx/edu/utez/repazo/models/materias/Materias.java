package mx.edu.utez.repazo.models.materias;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "materias")
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Materias {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(nullable = false)
    String nombre;

}
