package mx.edu.utez.repazo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepazoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepazoApplication.class, args);
	}

}
