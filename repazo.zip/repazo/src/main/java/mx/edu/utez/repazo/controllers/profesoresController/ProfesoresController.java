package mx.edu.utez.repazo.controllers.profesoresController;

import mx.edu.utez.repazo.controllers.profesoresController.dto.ProfesorDTO;
import mx.edu.utez.repazo.models.profesores.Profesores;
import mx.edu.utez.repazo.services.profesoresServices.ProfesoresServices;
import mx.edu.utez.repazo.utils.CustomResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/profesor")
@CrossOrigin(origins = {"*"})
public class ProfesoresController {
    @Autowired
    ProfesoresServices services;

    @GetMapping("/")
    public ResponseEntity<CustomResponse<List<Profesores>>> getAll(){
        return new ResponseEntity<>(
                this.services.getAll(),
                HttpStatus.OK
        );
    }
    @GetMapping("/{id}")
    public ResponseEntity<CustomResponse<Profesores>> getOne(@PathVariable("id") Long id ){
        return new ResponseEntity<>(
                this.services.getOne(id),
                HttpStatus.OK
        );
    }

    @PostMapping("/")
    public ResponseEntity<CustomResponse<Profesores>> save(@RequestBody ProfesorDTO profesorDTO, @Valid BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(
                    null,
                    HttpStatus.BAD_REQUEST
            );
        }
        return new ResponseEntity<>(
                this.services.insert(profesorDTO.getProfesor()),
                HttpStatus.CREATED
        );
    }

    @PutMapping("/")
    public ResponseEntity<CustomResponse<Profesores>> update(@RequestBody ProfesorDTO profesorDTO, @Valid BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(
                    null,
                    HttpStatus.BAD_REQUEST
            );
        }
        return new ResponseEntity<>(
                this.services.update(profesorDTO.getProfesor()),
                HttpStatus.CREATED
        );
    }
}
